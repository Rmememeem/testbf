package com.example.babyfoot.model

enum class MatchType {
    SOLO,
    DUO
}
