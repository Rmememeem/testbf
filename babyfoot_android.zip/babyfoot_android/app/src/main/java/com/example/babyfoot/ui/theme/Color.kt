package com.example.babyfoot.ui.theme

import androidx.compose.ui.graphics.Color

val Emerald = Color(0xFF2ECC71)
val EmeraldDark = Color(0xFF1E8449)
val Midnight = Color(0xFF17202A)
val Cloud = Color(0xFFE5E8E8)
val Flame = Color(0xFFE74C3C)
val Indigo = Color(0xFF5B6DEF)
val Gold = Color(0xFFF1C40F)
